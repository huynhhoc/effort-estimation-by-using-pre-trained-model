import torch
import pkg_resources
from isbsg.isbsgmodel import isbsgmodel

def load_pretrained_model():
    # Load the pre-trained model weights    
    state_dict_path = pkg_resources.resource_filename('isbsg', './weights/isbsgmodel.pth')
    state_dict = torch.load(state_dict_path)   
    # Create a new instance of the isbsgmodel
    model = isbsgmodel()
    
    # Load the state dict into the model
    model.load_state_dict(state_dict)
    
    # Set the model in evaluation mode
    model.eval()
    
    return model
