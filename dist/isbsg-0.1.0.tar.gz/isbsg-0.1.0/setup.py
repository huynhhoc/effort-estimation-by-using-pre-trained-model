from setuptools import setup

setup(
    name='isbsg',
    version='0.1.0',
    packages=['isbsg'],
    package_data={'isbsg': ['./weights/isbsgmodel.pth']},
    install_requires=['torch>=1.8.0'],
    author='Huynh Thai Hoc',
    author_email='huynhhoc@gmail.com',
    description='ISBSG library description',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)
